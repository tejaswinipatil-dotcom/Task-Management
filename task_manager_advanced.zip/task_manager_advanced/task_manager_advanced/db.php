<?php
// db.php - use in all pages
session_start();
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'TaskManager';

$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($conn->connect_error) {
    die('DB Connection failed: ' . $conn->connect_error);
}

function e($s) {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

function log_activity($conn, $user_id, $action, $ref=null) {
    $stmt = $conn->prepare('INSERT INTO activity_logs (user_id, action, reference_id) VALUES (?, ?, ?)');
    $stmt->bind_param('isi', $user_id, $action, $ref);
    $stmt->execute();
}
?>