<?php
include 'db.php';
if (isset($_SESSION['user_id'])) {
    log_activity($conn, $_SESSION['user_id'], 'logout', null);
}
session_unset(); session_destroy();
header('Location: login.php'); exit;
