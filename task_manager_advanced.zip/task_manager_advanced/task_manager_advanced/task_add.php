<?php
include 'db.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: dashboard.php'); exit; }
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }
$uid = (int)$_SESSION['user_id'];
$title = trim($_POST['title']);
$desc = trim($_POST['description']);
$priority = in_array($_POST['priority'], ['Low','Medium','High','Critical'])?$_POST['priority']:'Medium';
$due = $_POST['due_date']?:null;
$project_id = $_POST['project_id']?intval($_POST['project_id']):null;
$stmt = $conn->prepare('INSERT INTO tasks (user_id,project_id,title,description,priority,due_date) VALUES (?,?,?,?,?,?)');
$stmt->bind_param('iissss', $uid, $project_id, $title, $desc, $priority, $due);
$stmt->execute();
log_activity($conn, $uid, 'create_task', $stmt->insert_id);
header('Location: dashboard.php');
