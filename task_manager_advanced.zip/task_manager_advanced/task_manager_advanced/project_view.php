<?php
include 'db.php';
if (!isset($_SESSION['user_id'])) header('Location: login.php');
$uid=(int)$_SESSION['user_id'];
if (!isset($_GET['id'])) header('Location: projects.php');
$pid=(int)$_GET['id'];
$pr = $conn->prepare('SELECT * FROM projects WHERE id=? AND user_id=?'); $pr->bind_param('ii',$pid,$uid); $pr->execute(); $proj=$pr->get_result()->fetch_assoc();
if (!$proj) header('Location: projects.php');
$tasks = $conn->prepare('SELECT * FROM tasks WHERE project_id=? AND user_id=?'); $tasks->bind_param('ii',$pid,$uid); $tasks->execute(); $tasks=$tasks->get_result();
?>
<!doctype html><html><head><meta charset="utf-8"><title><?= e($proj['name']) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css"></head><body class="bg-light">
<div class="container py-4"><h3><?= e($proj['name']) ?></h3><p><?= e($proj['description']) ?></p>
<table class="table"><thead><tr><th>#</th><th>Title</th><th>Priority</th><th>Status</th></tr></thead><tbody>
<?php while($t=$tasks->fetch_assoc()): ?>
<tr><td><?= $t['id'] ?></td><td><?= e($t['title']) ?></td><td><?= e($t['priority']) ?></td><td><?= e($t['status']) ?></td></tr>
<?php endwhile; ?>
</tbody></table><p><a href="projects.php">Back</a></p></div></body></html>
