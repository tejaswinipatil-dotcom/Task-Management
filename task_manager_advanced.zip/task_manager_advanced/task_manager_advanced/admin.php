<?php
include 'db.php';
if (!isset($_SESSION['user_id']) || !$_SESSION['is_admin']) header('Location: login.php');
$users = $conn->query('SELECT id,username,email,is_admin,created_at FROM users');
?>
<!doctype html><html><head><meta charset="utf-8"><title>Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css"></head><body class="bg-light">
<div class="container py-4"><h3>Admin Panel</h3>
<table class="table"><thead><tr><th>ID</th><th>Username</th><th>Email</th><th>Admin</th><th>Created</th></tr></thead><tbody>
<?php while($u=$users->fetch_assoc()): ?>
<tr><td><?= $u['id'] ?></td><td><?= e($u['username']) ?></td><td><?= e($u['email']) ?></td><td><?= $u['is_admin']?'Yes':'No' ?></td><td><?= $u['created_at'] ?></td></tr>
<?php endwhile; ?>
</tbody></table><p><a href="dashboard.php">Back</a></p></div></body></html>
