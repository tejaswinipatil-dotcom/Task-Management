# Advanced Task Manager (PHP + MySQL)

## Features
- Multi-user accounts with hashed passwords
- Per-user tasks (status, priority, due date)
- Projects (user-created)
- Profile (avatar upload)
- Admin panel
- Activity logs
- Bootstrap 5 UI, responsive
- Dark/Light theme per user

## Setup
1. Start XAMPP (Apache + MySQL).
2. Copy the folder `task_manager_advanced` into `C:/xampp/htdocs/`.
3. Open phpMyAdmin (`http://localhost/phpmyadmin`), import `init_db.sql` or run its content.
4. (Optional) Fix the admin password hash in `init_db.sql` or create an admin via registration.
5. Ensure `assets/uploads` is writable for avatars.
6. Open: `http://localhost/task_manager_advanced/`

Included sample screenshot available at `assets/uploads/screenshot.png`.
