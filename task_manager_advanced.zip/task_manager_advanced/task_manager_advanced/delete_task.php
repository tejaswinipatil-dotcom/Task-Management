<?php
include 'db.php';
if (!isset($_SESSION['user_id'])) header('Location: login.php');
$uid = (int)$_SESSION['user_id'];
if (!isset($_GET['id'])) header('Location: dashboard.php');
$tid = (int)$_GET['id'];
$stmt = $conn->prepare('DELETE FROM tasks WHERE id=? AND user_id=?');
$stmt->bind_param('ii',$tid,$uid); $stmt->execute();
log_activity($conn, $uid, 'delete_task', $tid);
header('Location: dashboard.php');
