<?php
include 'db.php';
if (!isset($_SESSION['user_id'])) { 
    header('Location: login.php'); 
    exit; 
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { 
    header('Location: dashboard.php'); 
    exit; 
}

$uid = (int)$_SESSION['user_id'];

$title = trim($_POST['title']);
$desc = trim($_POST['description']);
$priority = in_array($_POST['priority'], ['Low','Medium','High','Critical']) ? $_POST['priority'] : 'Medium';
$due = !empty($_POST['due_date']) ? $_POST['due_date'] : NULL;
$project_id = !empty($_POST['project_id']) ? (int)$_POST['project_id'] : NULL;

// Prepare statement
$stmt = $conn->prepare('INSERT INTO tasks (user_id, project_id, title, description, priority, due_date) 
                        VALUES (?, ?, ?, ?, ?, ?)');

// Bind NULL properly
$stmt->bind_param('iissss', $uid, $project_id, $title, $desc, $priority, $due);

if (!$stmt->execute()) {
    die("SQL Error: " . $stmt->error);
}

log_activity($conn, $uid, 'create_task', $stmt->insert_id);

header('Location: dashboard.php');
exit;
?>
