<?php
include 'db.php';
if (!isset($_SESSION['user_id'])) header('Location: login.php');
$uid = (int)$_SESSION['user_id'];
$err = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (isset($_POST['update_profile'])) {
        $display = trim($_POST['display_name']);
        $theme = $_POST['theme']=='dark'?'dark':'light';
        // avatar upload
        if (!empty($_FILES['avatar']['name'])) {
            $fn = basename($_FILES['avatar']['name']);
            $target = 'assets/uploads/' . time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/','', $fn);
            if (move_uploaded_file($_FILES['avatar']['tmp_name'], $target)) {
                $stmt = $conn->prepare('UPDATE users SET display_name=?, avatar=?, theme=? WHERE id=?');
                $stmt->bind_param('sssi',$display,$target,$theme,$uid); $stmt->execute();
            } else $err='Upload failed';
        } else {
            $stmt = $conn->prepare('UPDATE users SET display_name=?, theme=? WHERE id=?');
            $stmt->bind_param('ssi',$display,$theme,$uid); $stmt->execute();
        }
        log_activity($conn,$uid,'update_profile',null);
        header('Location: profile.php'); exit;
    } elseif (isset($_POST['change_pass'])) {
        $old = $_POST['old_pass']; $new = $_POST['new_pass'];
        $r = $conn->prepare('SELECT password FROM users WHERE id=?'); $r->bind_param('i',$uid); $r->execute(); $row=$r->get_result()->fetch_assoc();
        if (password_verify($old,$row['password'])) {
            $nh = password_hash($new, PASSWORD_DEFAULT);
            $u = $conn->prepare('UPDATE users SET password=? WHERE id=?'); $u->bind_param('si',$nh,$uid); $u->execute();
            log_activity($conn,$uid,'change_password',null);
            $err='Password updated';
        } else $err='Current password incorrect';
    }
}
$me = $conn->prepare('SELECT * FROM users WHERE id=?'); $me->bind_param('i',$uid); $me->execute(); $me = $me->get_result()->fetch_assoc();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Profile</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css"></head><body class="bg-light">
<div class="container py-4"><h3>Profile</h3>
<?php if($err): ?><div class="alert alert-info"><?= e($err) ?></div><?php endif; ?>
<form method="post" enctype="multipart/form-data" class="card p-3 mb-3">
<label>Display name</label><input class="form-control" name="display_name" value="<?= e($me['display_name']) ?>">
<label>Avatar</label><input type="file" name="avatar" class="form-control">
<label>Theme</label><select name="theme" class="form-select"><option value="light" <?= $me['theme']=='light'?'selected':''?>>Light</option><option value="dark" <?= $me['theme']=='dark'?'selected':''?>>Dark</option></select>
<button class="btn btn-primary mt-2" name="update_profile">Save</button>
</form>
<div class="card p-3">
<h5>Change Password</h5>
<form method="post">
<input type="password" name="old_pass" class="form-control mb-2" placeholder="Current password" required>
<input type="password" name="new_pass" class="form-control mb-2" placeholder="New password" required>
<button class="btn btn-warning" name="change_pass">Change</button>
</form>
</div>
<p><a href="dashboard.php">Back</a></p>
</div></body></html>
