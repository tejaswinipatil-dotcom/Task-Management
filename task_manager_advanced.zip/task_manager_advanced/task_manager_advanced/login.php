<?php
include 'db.php';


$err = '';

if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = trim($_POST['user']);
    $p = $_POST['password'];

    // FIXED: ensure query matches your DB
    $stmt = $conn->prepare("SELECT id, username, email, password, is_admin FROM users WHERE username=? OR email=?");

    if (!$stmt) {
        die("SQL prepare error: " . $conn->error);
    }

    $stmt->bind_param('ss', $u, $u);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($row = $res->fetch_assoc()) {
        if (password_verify($p, $row['password'])) {

            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['is_admin'] = $row['is_admin'];

            // Optional function — only if you create activity logs
            // log_activity($conn, $row['id'], 'login', null);

            header('Location: dashboard.php');
            exit;
        } else {
            $err = 'Invalid credentials';
        }
    } else {
        $err = 'Invalid credentials';
    }
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-light">
<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-md-5">
      <div class="card p-4">

        <h3>Login</h3>

        <?php if(isset($_GET['registered'])): ?>
            <div class="alert alert-success">Registered. Please login.</div>
        <?php endif; ?>

        <?php if($err): ?>
            <div class="alert alert-danger"><?= e($err) ?></div>
        <?php endif; ?>

        <form method="post">
          <div class="mb-2">
            <input class="form-control" name="user" placeholder="Username or email" required>
          </div>
          <div class="mb-2">
            <input class="form-control" type="password" name="password" placeholder="Password" required>
          </div>
          <button class="btn btn-primary">Login</button>
          <a class="btn btn-link" href="index.php">Register</a>
        </form>

      </div>
    </div>
  </div>
</div>
</body>
</html>
