<?php
include 'db.php';
if (!isset($_SESSION['user_id'])) header('Location: login.php');
$uid = (int)$_SESSION['user_id'];
// admin can view all
if ($_SESSION['is_admin']) {
    $res = $conn->query('SELECT a.*, u.username FROM activity_logs a LEFT JOIN users u ON a.user_id=u.id ORDER BY a.created_at DESC LIMIT 200');
} else {
    $stmt = $conn->prepare('SELECT a.*, u.username FROM activity_logs a LEFT JOIN users u ON a.user_id=u.id WHERE a.user_id=? ORDER BY a.created_at DESC LIMIT 200');
    $stmt->bind_param('i',$uid); $stmt->execute(); $res = $stmt->get_result();
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Activity</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css"></head><body class="bg-light">
<div class="container py-4"><h4>Activity</h4>
<table class="table"><thead><tr><th>Time</th><th>User</th><th>Action</th><th>Ref</th></tr></thead><tbody>
<?php while($row = $res->fetch_assoc()): ?>
<tr><td><?= $row['created_at'] ?></td><td><?= e($row['username']) ?></td><td><?= e($row['action']) ?></td><td><?= e($row['reference_id']) ?></td></tr>
<?php endwhile; ?>
</tbody></table><p><a href="dashboard.php">Back</a></p></div></body></html>
