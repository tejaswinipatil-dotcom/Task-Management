<?php
include 'db.php';
if (!isset($_SESSION['user_id'])) header('Location: login.php');
$uid = (int)$_SESSION['user_id'];
if (!isset($_GET['id'])) header('Location: dashboard.php');
$tid = (int)$_GET['id'];
// fetch
$stmt = $conn->prepare('SELECT * FROM tasks WHERE id=? AND user_id=?');
$stmt->bind_param('ii',$tid,$uid);
$stmt->execute(); $task = $stmt->get_result()->fetch_assoc();
if (!$task) { header('Location: dashboard.php'); exit; }
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $title=trim($_POST['title']); $desc=trim($_POST['description']);
    $status = in_array($_POST['status'], ['Pending','In Progress','Completed','Cancelled'])?$_POST['status']:'Pending';
    $priority = in_array($_POST['priority'], ['Low','Medium','High','Critical'])?$_POST['priority']:'Medium';
    $due = $_POST['due_date']?:null;
    $proj = $_POST['project_id']?intval($_POST['project_id']):null;
    $upd = $conn->prepare('UPDATE tasks SET title=?,description=?,status=?,priority=?,due_date=?,project_id=? WHERE id=? AND user_id=?');
    $upd->bind_param('ssssiiii',$title,$desc,$status,$priority,$due,$proj,$tid,$uid);
    $upd->execute();
    log_activity($conn, $uid, 'update_task', $tid);
    header('Location: dashboard.php'); exit;
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Edit Task</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css"></head><body class="bg-light">
<div class="container py-4"><div class="card p-3"><h4>Edit Task</h4>
<form method="post">
 <input class="form-control mb-2" name="title" value="<?= e($task['title']) ?>" required>
 <textarea class="form-control mb-2" name="description"><?= e($task['description']) ?></textarea>
 <select class="form-select mb-2" name="status">
  <?php foreach(['Pending','In Progress','Completed','Cancelled'] as $s): ?>
    <option <?= $task['status']==$s?'selected':'' ?>><?= $s ?></option>
  <?php endforeach; ?>
 </select>
 <select class="form-select mb-2" name="priority">
  <?php foreach(['Low','Medium','High','Critical'] as $p): ?>
    <option <?= $task['priority']==$p?'selected':'' ?>><?= $p ?></option>
  <?php endforeach; ?>
 </select>
 <input type="date" class="form-control mb-2" name="due_date" value="<?= e($task['due_date']) ?>">
 <select class="form-select mb-2" name="project_id"><option value=''>No project</option>
 <?php $pr = $conn->prepare('SELECT id,name FROM projects WHERE user_id=?'); $pr->bind_param('i',$uid); $pr->execute(); $prs=$pr->get_result();
 while($p=$prs->fetch_assoc()): ?>
   <option value="<?= $p['id'] ?>" <?= $task['project_id']==$p['id']?'selected':'' ?>><?= e($p['name']) ?></option>
 <?php endwhile; ?>
 </select>
 <button class="btn btn-primary">Save</button>
 <a class="btn btn-link" href="dashboard.php">Cancel</a>
</form></div></div></body></html>
