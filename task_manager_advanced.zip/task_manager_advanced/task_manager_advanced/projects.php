<?php
include 'db.php';
if (!isset($_SESSION['user_id'])) header('Location: login.php');
$uid = (int)$_SESSION['user_id'];
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $name = trim($_POST['name']); $desc = trim($_POST['description']);
    $ins = $conn->prepare('INSERT INTO projects (user_id,name,description) VALUES (?,?,?)');
    $ins->bind_param('iss',$uid,$name,$desc); $ins->execute(); log_activity($conn,$uid,'create_project',$ins->insert_id);
    header('Location: projects.php'); exit;
}
$pr = $conn->prepare('SELECT * FROM projects WHERE user_id=?'); $pr->bind_param('i',$uid); $pr->execute(); $projects=$pr->get_result();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Projects</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css"></head><body class="bg-light">
<div class="container py-4">
  <h4>Your Projects</h4>
  <form method="post" class="mb-3"><input class="form-control mb-2" name="name" placeholder="Project name" required>
  <textarea class="form-control mb-2" name="description" placeholder="Description"></textarea>
  <button class="btn btn-primary">Create</button></form>
  <ul class="list-group">
  <?php while($p=$projects->fetch_assoc()): ?>
    <li class="list-group-item d-flex justify-content-between"><?= e($p['name']) ?><span><a class="btn btn-sm btn-outline-secondary" href="project_view.php?id=<?= $p['id'] ?>">View</a></span></li>
  <?php endwhile; ?>
  </ul>
  <p><a href="dashboard.php">Back to dashboard</a></p>
</div></body></html>
