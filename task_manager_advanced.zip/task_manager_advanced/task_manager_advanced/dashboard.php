<?php
include 'db.php';
if (!isset($_SESSION['user_id'])) header('Location: login.php');
$uid = (int)$_SESSION['user_id'];
// filters
$q = 'SELECT t.*, p.name as project_name FROM tasks t LEFT JOIN projects p ON t.project_id=p.id WHERE t.user_id=?';
$params = [$uid];
$stmt = $conn->prepare($q);
$stmt->bind_param('i', $uid);
$stmt->execute();
$tasks = $stmt->get_result();
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
  <div class="container">
    <a class="navbar-brand" href="dashboard.php">TaskMgr</a>
    <div class="ms-auto">
      <span class="me-2">Hello, <?= e($_SESSION['username']) ?></span>
      <a class="btn btn-outline-secondary btn-sm" href="profile.php">Profile</a>
      <?php if($_SESSION['is_admin']): ?><a class="btn btn-warning btn-sm" href="admin.php">Admin</a><?php endif; ?>
      <a class="btn btn-danger btn-sm" href="logout.php">Logout</a>
    </div>
  </div>
</nav>
<div class="container py-4">
  <div class="row">
    <div class="col-md-4">
      <div class="card p-3 mb-3">
        <h5>Add Task</h5>
        <form method="post" action="add_task.php">
          <div class="mb-2"><input name="title" class="form-control" placeholder="Title" required></div>
          <div class="mb-2"><textarea name="description" class="form-control" placeholder="Description"></textarea></div>
          <div class="mb-2"><select name="priority" class="form-select"><option>Low</option><option selected>Medium</option><option>High</option><option>Critical</option></select></div>
          <div class="mb-2"><input type="date" name="due_date" class="form-control"></div>
          <div class="mb-2"><select name="project_id" class="form-select"><option value=''>No project</option>
          <?php
          $pr = $conn->prepare('SELECT id,name FROM projects WHERE user_id=?');
          $pr->bind_param('i',$uid); $pr->execute(); $prs = $pr->get_result();
          while($p = $prs->fetch_assoc()): ?>
            <option value="<?= $p['id'] ?>"><?= e($p['name']) ?></option>
          <?php endwhile; ?>
          </select></div>
          <button class="btn btn-primary">Add</button>
        </form>
      </div>
      <div class="card p-3">
        <h6>Projects</h6>
        <a href="projects.php" class="btn btn-sm btn-outline-primary">Manage Projects</a>
      </div>
    </div>
    <div class="col-md-8">
      <div class="card p-3">
        <h5>Your Tasks</h5>
        <table class="table">
          <thead><tr><th>#</th><th>Title</th><th>Priority</th><th>Status</th><th>Due</th><th>Project</th><th>Action</th></tr></thead>
          <tbody>
          <?php while($t = $tasks->fetch_assoc()): ?>
           <tr class="<?php if($t['status']=='Completed') echo 'table-success'; elseif($t['due_date'] && strtotime($t['due_date']) < time() && $t['status']!='Completed') echo 'table-danger'; ?>">
            <td><?= $t['id'] ?></td>
            <td><?= e($t['title']) ?></td>
            <td><?= e($t['priority']) ?></td>
            <td><?= e($t['status']) ?></td>
            <td><?= e($t['due_date']) ?></td>
            <td><?= e($t['project_name']) ?></td>
            <td>
              <a href="edit_task.php?id=<?= $t['id'] ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
              <a href="delete_task.php?id=<?= $t['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete?')">Delete</a>
            </td>
           </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
      </div>
      <div class="card p-3 mt-3">
        <h6>Activity Log</h6>
        <a href="activity.php" class="btn btn-link">View Full Activity</a>
      </div>
    </div>
  </div>
</div>
</body>
</html>
