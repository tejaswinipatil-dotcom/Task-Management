<?php
include 'db.php';

if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $user = trim($_POST['username']);
    $email = trim($_POST['email']);
    $pass = $_POST['password'];

    if ($user === '' || $email === '' || $pass === '') {
        $err = 'All fields required';
    } else {

        // check exists
        $stmt = $conn->prepare('SELECT id FROM users WHERE username=? OR email=?');

        if (!$stmt) {
            die("SQL Error: " . $conn->error);
        }

        $stmt->bind_param('ss', $user, $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $err = 'User or email already exists';
        } else {

            $hash = password_hash($pass, PASSWORD_DEFAULT);

            $ins = $conn->prepare('INSERT INTO users (username,email,password,display_name) VALUES (?,?,?,?)');

            if (!$ins) {
                die("Insert Prepare Error: " . $conn->error);
            }

            $disp = $user;

            $ins->bind_param('ssss', $user, $email, $hash, $disp);
            $ins->execute();

            header('Location: login.php?registered=1');
            exit;
        }
    }
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Task Manager - Register</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-light">

<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card p-4">

        <h3>Create account</h3>

        <?php if ($err): ?>
            <div class="alert alert-danger"><?= e($err) ?></div>
        <?php endif; ?>

        <form method="post">
          <div class="mb-2">
            <label>Username</label>
            <input class="form-control" name="username" required>
          </div>

          <div class="mb-2">
            <label>Email</label>
            <input class="form-control" type="email" name="email" required>
          </div>

          <div class="mb-2">
            <label>Password</label>
            <input class="form-control" type="password" name="password" required>
          </div>

          <button class="btn btn-primary">Register</button>
          <a class="btn btn-link" href="login.php">Login</a>

        </form>

      </div>
    </div>
  </div>
</div>

</body>
</html>
